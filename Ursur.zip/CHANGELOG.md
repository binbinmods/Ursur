# Version 1.1.0

Updated for v1.5.0. 

Fixed some of the Jankiness in Bristly Hide. 

Minor nerfs to Bearly Noticeable. 

Modernized some of the backend.

# Version 1.0.0 - 1.0.19

Initial release and bug fixes